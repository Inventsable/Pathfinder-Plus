export default {
  unite:
    "/version 3" +
    "/name [ 15" +
    "	4c6976652d5061746866696e646572" +
    "]" +
    "/isOpen 1" +
    "/actionCount 1" +
    "/action-1 {" +
    "	/name [ 5" +
    "		756e697465" +
    "	]" +
    "	/keyIndex 0" +
    "	/colorIndex 0" +
    "	/isOpen 1" +
    "	/eventCount 1" +
    "	/event-1 {" +
    "		/useRulersIn1stQuadrant 0" +
    "		/internalName (ai_plugin_pathfinder)" +
    "		/localizedName [ 10" +
    "			5061746866696e646572" +
    "		]" +
    "		/isOpen 0" +
    "		/isOn 1" +
    "		/hasDialog 0" +
    "		/parameterCount 1" +
    "		/parameter-1 {" +
    "			/key 1851878757" +
    "			/showInPalette -1" +
    "			/type (enumerated)" +
    "			/name [ 3" +
    "				416464" +
    "			]" +
    "			/value 0" +
    "		}" +
    "	}" +
    "}" +
    "",
};
